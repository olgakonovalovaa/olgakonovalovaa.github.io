let img;


function preload(){
  img = loadImage("mickey.jpeg");
}

function setup() {
  createCanvas(500, 500);
  stroke(0);
  strokeWeight(0);
}

function draw() {
  console.log(mouseX + ", " + mouseY);
  // image(img, 0,0,img.width/2, img.height/2);
  


fill(0);      //ears
ellipse (260, 277, 245, 245);
    push ();
  strokeWeight(3);
  translate(265,91);
  rotate (-PI/3);
 ellipse(0, 0,137,150);
pop();
  push ();
  translate(78,220);
  rotate (-PI/10);
 ellipse(0,0,140,170);
pop();
  
 



  fill (240,200,160)      //beige
  strokeWeight(0);
  ellipse (311,285, 20,20)
  ellipse (235,357,120,85);
  ellipse (280,360,90,112);
  
  push ();                //beige
  translate(253,245);
  rotate (-PI/7);
  ellipse (0,0,103,160);
  pop(); 
  
   push ();               //beige
  translate(322,232);
  rotate (-PI/10);
  ellipse (0,0,65,120);
  pop();
  
  push ();               //beige
  translate(339,321);
  rotate (PI/4.5);
  ellipse (0,0,88,160);
  pop(); 
  
    push ();            //left eye
    fill (255);
  strokeWeight(3);
  translate(278,265);
  rotate (-PI/10);
  ellipse (0,0, 30,90);
    pop();
  
  
  push ();              //eyeball
  fill (0);
  translate(288,293);
  rotate (-PI/9);
  ellipse (0,0, 15,35);
pop();
  
  
   if (mouseX<width/2) {
      push ();          //left eye
    fill (255);
  strokeWeight(3);
  translate(325,248);
  rotate (-PI/10);
  ellipse (0,0, 27,85);
    pop();
    
      push ();          //eyeball
  fill (0);
  translate(332,275);
  rotate (-PI/9);
  ellipse (0,0, 15,35);
pop();
    
  } 
  else {
   
 noFill();
     stroke(0);
    strokeWeight(2);
    
    beginShape();
    vertex(297,313);
    quadraticVertex(308,296,336,289);
    endShape();
    
    beginShape();
    vertex(319,280);
    quadraticVertex(330,255,340,261);
    endShape();
    
    beginShape();
    vertex(329,284);
    quadraticVertex(337,277,341,268);
    endShape();
    
    beginShape();
    vertex(315,263);
    quadraticVertex(324,244,334,245);
    endShape();
    
  }
  
    push ();            //nose
    fill (0);
    translate(335,324);
    rotate (PI/3.5);
    ellipse (0,0, 45,72);
    pop();
   

 //smile
  
     noFill();
     stroke(0);
    strokeWeight(2);
    beginShape();
    vertex(175,365);
    quadraticVertex(183,395,247,401);
    quadraticVertex(288,435,318,390);
   quadraticVertex(371,367,400,303);
    quadraticVertex(409,264,380,253);
    endShape();
  
 beginShape();
    vertex(320,380);
    quadraticVertex(382,353,382,288);
    endShape();
  

    fill (0);
    strokeWeight(0);
    beginShape();
    vertex(233,353);
    quadraticVertex(278,388,322,378);
    quadraticVertex(302,403,282,403);
   quadraticVertex(253,398,233,353);
    endShape();
  
     beginShape();
    vertex(222,363);
    quadraticVertex(228,352,247,344);
    endShape();
  
    beginShape();
    vertex(374,288);
    quadraticVertex(380,284,388,288);
    endShape();
  
  
    fill (255,120,120);      //tongue
    beginShape();
    vertex(250,378);
    quadraticVertex(262,369,280,395);
    quadraticVertex(283,388,279,387);
    quadraticVertex(298,380,304,393);
    quadraticVertex(296,400,282,400);
    quadraticVertex(275,400,272,397);
    quadraticVertex(258,392,250,378);
    endShape();
}
